#!/usr/bin/env bash

clear && tail -f ~/homebrew/logs/AllyDeckyCompanion/"$(ls -Art ~/homebrew/logs/AllyDeckyCompanion | tail -n 1)"
